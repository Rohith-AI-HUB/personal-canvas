// Types for the structures specific to Hrana over WebSockets.
export * from "../shared/proto.js";
