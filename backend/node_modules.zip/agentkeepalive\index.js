'use strict';

const HttpAgent = require('./lib/agent');
module.exports = HttpAgent;
module.exports.HttpAgent = HttpAgent;
module.exports.HttpsAgent = require('./lib/https_agent');
module.exports.constants = require('./lib/constants');
