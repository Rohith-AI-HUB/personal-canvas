module.exports = require('neostandard')()
