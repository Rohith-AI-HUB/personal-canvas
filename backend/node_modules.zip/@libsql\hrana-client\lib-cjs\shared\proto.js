"use strict";
// Types for the protocol structures that are shared for WebSocket and HTTP
Object.defineProperty(exports, "__esModule", { value: true });
