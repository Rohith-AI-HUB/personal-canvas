"use strict";

const _Request = Request;
const _Headers = Headers;

const _fetch = fetch;

module.exports = { fetch: _fetch, Request: _Request, Headers: _Headers };
