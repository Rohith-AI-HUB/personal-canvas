"use strict";
const { WebSocket } = require("ws");
module.exports = { WebSocket };
