const _Request = Request;
const _Headers = Headers;

const _fetch = fetch;

export { _fetch as fetch, _Request as Request, _Headers as Headers};
