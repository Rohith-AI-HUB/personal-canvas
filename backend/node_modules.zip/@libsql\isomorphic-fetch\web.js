const _fetch = fetch;
const _Request = Request;
const _Headers = Headers;
export {
    _fetch as fetch,
    _Request as Request,
    _Headers as Headers,
};
