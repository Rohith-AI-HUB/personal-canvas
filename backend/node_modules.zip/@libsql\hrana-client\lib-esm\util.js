import { InternalError } from "./errors.js";
export function impossible(value, message) {
    throw new InternalError(message);
}
