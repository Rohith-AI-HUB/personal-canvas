export const VARINT = 0;
export const FIXED_64 = 1;
export const LENGTH_DELIMITED = 2;
export const GROUP_START = 3;
export const GROUP_END = 4;
export const FIXED_32 = 5;
