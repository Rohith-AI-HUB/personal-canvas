module.exports = require("./color.cjs").default;
